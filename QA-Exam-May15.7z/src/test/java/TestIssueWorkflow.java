import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.openqa.selenium.By;
import org.openqa.selenium.Dimension;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.support.ui.Select;

import java.util.concurrent.TimeUnit;

/**
 * Created by Alexander7337 on 5/15/2016.
 */
public class TestIssueWorkflow {

    private WebDriver driver;
    private static final String username = "admin";
    private static final String password = "admin";
    private static String stringExpected = "Title";
    private static String stringInDes = "Description";

    @Before
    public void setUp() {
        driver = new FirefoxDriver();

        driver.manage().timeouts().implicitlyWait(80, TimeUnit.SECONDS);

        Dimension dim = new Dimension(1400,1200);

        driver.manage().window().setSize(dim);

        System.out.println();
    }

    @Test
    public void testCreateIssue_ValidUsername_ExpectedResult() {
        login_ValidUsername();

        WebElement createIssueLink = driver.findElement(By.linkText("link=Create Issue"));
        createIssueLink.click();

        WebElement title = driver.findElement(By.id("title"));
        title.sendKeys(stringExpected);

        WebElement description = driver.findElement(By.id("description"));
        description.sendKeys(stringInDes);

        WebElement type = driver.findElement(By.id("type"));

        Select select = new Select(driver.findElement(By.name("Bug")));

        WebElement createIssue = driver.findElement(By.xpath("/html/body/div[1]/div/div/form/fieldset/div[6]/div/button[2]"));
        createIssue.click();

    }

    @After
    public void tearDown() {

        WebElement logOut = driver.findElement(By.linkText("link=Log out"));
        logOut.click();

    }

    public void login_ValidUsername() {
        driver.get("http://localhost:8087/issuetracker/");

        WebElement usernameField = driver.findElement(By.id("username"));
        usernameField.sendKeys(username);

        WebElement passwordField = driver.findElement(By.id("password"));
        passwordField.sendKeys(password);

        WebElement loginBut = driver.findElement(By.xpath("/html/body/div/div/div/form/fieldset/div[3]/div/button[2]"));
        loginBut.click();
    }


}
